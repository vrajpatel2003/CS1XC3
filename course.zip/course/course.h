/**
 * @file course.h
 * @author Vraj Patel (patev38@mcmaster.ca)
 * @brief Course Struct for managing course information and type definitions for course functions.
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "student.h"
#include <stdbool.h>
 
/**
 * @brief Course struct stores a course with fields name, code, student type, and total_students.
 * 
 */
typedef struct _course 
{
  char name[100]; /**< the course's title */
  char code[10]; /**< the course code */
  Student *students; /**< the students enrolled in the course */
  int total_students; /**< total number of students enrolled in the course */
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


