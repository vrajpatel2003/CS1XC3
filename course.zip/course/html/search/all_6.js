var searchData=
[
  ['id_0',['id',['../struct__student.html#adaee78078859cdecdbe9128dd655b748',1,'_student']]]
];
