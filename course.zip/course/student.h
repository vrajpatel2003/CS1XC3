/**
 * @file student.h
 * @author Vraj Patel (patev38@mcmaster.ca)
 * @brief Student Struct for managing student information and type definitions for student functions.
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */

/**
 * @brief Student struct stores a course with fields first_name, last_name, id, grades, num_grades.
 * 
 */
typedef struct _student 
{ 
  char first_name[50]; /**< the student's first name */ 
  char last_name[50]; /**< the student's last name */ 
  char id[11]; /**< the student's id */ 
  double *grades;  /**< the student's grades */ 
  int num_grades;  /**< the number of student's grades */ 
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
