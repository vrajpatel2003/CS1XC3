/**
 * @file course.c
 * @author Vraj Patel (patev38@mcmaster.ca)
 * @brief Course library which contains course functions used for managing the course and viewing information about the course like top student, passing student and enroll student.
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>
 
/**
 * @brief This enroll_student function will add the student to the course. 
 * This will be done by adding the student to the end of the list. 
 * Calloc is used to set the list size when it is equal to 1, but realloc is used otherwise to resize the list.
 * 
 * 
 * @param course 
 * @param student 
 * @return nothing
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    //initializes memmory when only 1 student is enrolled
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    course->students = 
      //increases memory when more students are enrolled
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief Prints all course information such as name, code, # of students, students
 * 
 * @param course 
 * @return nothing
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  //loops through all students in the course
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * @brief Searches the course for the top student by their averages. 
 * Loops through each student in the course to find the student with the best avg.
 * 
 * @param course 
 * @return Student* 
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
  //loops through all students in the course
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * @brief Finds the list of students that are passing the course. 
 * Loops through the students in the course, and stores the one's with averages above 50 in a list.
 * 
 * @param course 
 * @param total_passing 
 * @return Student* 
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  //loops through all students in the course
  for (int i = 0; i < course->total_students; i++) 
    //counts which students have an avg greater than 50
    if (average(&course->students[i]) >= 50) count++;
  
  passing = calloc(count, sizeof(Student));

  int j = 0;
  //loops through all students in the course
  for (int i = 0; i < course->total_students; i++)
  {
    //if they're passing, adds them to the passing list
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}